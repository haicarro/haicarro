import json

def lambda_handler(event, context):
    return {
        "status": 200,
        "body": "hello world!"
    }